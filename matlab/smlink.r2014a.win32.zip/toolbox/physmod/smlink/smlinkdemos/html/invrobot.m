%% Robot Arm

% Copyright 2008-2012 The MathWorks, Inc.

%% CAD Software Requirements
% This CAD assembly can be opened in Autodesk(R) Inventor(R) 2009 and higher.
%% Assembly
% Link to the <matlab:system(fullfile(matlabroot,'toolbox/physmod/smlink/smlinkdemos/inventor/robot','robot.iam')) assembly>
%
% This is a view of the robot arm assembly as modelled in Inventor(R).
%
% <<robot_inv.jpg>>
% 
